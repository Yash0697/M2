/*  addNames()
  {
  this.namesArray.push(this.name1);
  }

test(){
  alert('Your ID is : '+this.UID);
  }

  salary()
  {
  let total  = (+this.Basic) + (+this.HRA) + (+this.DA) - (-this.Tax);
  alert("Your Gross Salary is : "+total);
  this.result = total;
  }

  product(){
  if((this.Pname==undefined) ||(this.PID)==undefined || (this.Ponline)==undefined || (this.Pcost)==undefined || this.PID.toString().length < 3)
    alert("One or many Fields are Empty");
  else
  {
  alert("New Product added successfully");
  if(this.Pmart==true)
  document.getElementById("big").innerHTML="Big Bazar";

  if(this.Dmart==true)
  document.getElementById("d").innerHTML="D Mart";

  if(this.Rmart==true)
  document.getElementById("r").innerHTML="Reliance";

  if(this.Mmart==true)
  document.getElementById("m").innerHTML="Mega Mart";
  console.log("Information displayed on screen")
  }
}

displayName(name:string){
alert("What is better than home ? : "+name);
}*/
