import { Component, OnInit } from '@angular/core';
import { EmployeeInfo } from '../EmployeeInfo';
import { Observable, of } from 'rxjs';
import { MatSort, MatSortable, MatTableDataSource } from '@angular/material';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeetable',
  templateUrl: './employeetable.component.html',
  styleUrls: ['./employeetable.component.css']
})
export class EmployeetableComponent implements OnInit {

  dataSource;
  emp:EmployeeInfo;
  displayedColumns = ["Employee ID", "Employee Name", "Employee Salary", "Employee Departmentt"];
  constructor(private empService:EmployeeService) {

   }

  ngOnInit(): void {

  /*this.empService.getEmployee().subscribe(result =>{
  if(!result){
  return;
  }
  this.dataSource = new MatTableDataSource(result);
  })*/
  }

}
