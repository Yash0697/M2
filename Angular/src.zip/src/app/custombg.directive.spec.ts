import { CustombgDirective } from './custombg.directive';

describe('CustombgDirective', () => {
  it('should create an instance', () => {
    const directive = new CustombgDirective();
    expect(directive).toBeTruthy();
  });
});
