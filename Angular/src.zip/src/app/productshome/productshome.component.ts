import { Component, OnInit } from '@angular/core';
import { Item } from '../Item';
import { Category } from '../Category';

@Component({
  selector: 'app-productshome',
  templateUrl: './productshome.component.html',
  styleUrls: ['./productshome.component.css']
})
export class ProductshomeComponent implements OnInit {

  items:Item[]=[
    new Item("Redmi Note 8", 12000, new Category("Mobile Phones"), 10000, "image")];
  constructor() { }

  ngOnInit(): void {
  }

}
