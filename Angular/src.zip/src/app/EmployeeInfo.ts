export class EmployeeInfo
{
emp_ID : number;
emp_Name : string;
emp_Sal : number;
emp_Dept: string;
constructor(emp_ID : number, emp_Name : string, emp_Sal : number, emp_Dept: string)
{
        this.emp_ID = emp_ID;
        this.emp_Name = emp_Name;
        this.emp_Sal = emp_Sal;
        this.emp_Dept = emp_Dept;
}
}
