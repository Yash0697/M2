import { Injectable } from '@angular/core';
import { EmployeeInfo } from './EmployeeInfo';

@Injectable({
  providedIn: 'root'
})
export class SortingHeaderService {

  constructor() { }

  sortPerID(empList:EmployeeInfo[])
  {

  }
}
