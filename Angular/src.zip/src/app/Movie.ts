export class Movie{

title:string;
year:number;
genre:string;
actors:string[];
constructor(title:string, year:number, genre:string, actors:string[]){
    this.title=title;
    this.year=year;
    this.genre=genre;
    this.actors=actors;
}

}