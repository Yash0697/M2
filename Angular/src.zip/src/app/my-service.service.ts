import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {

  constructor() { }

  add()
  {
  alert("File Added");
  }

  delete()
  {
  alert("File Deleted");
  }

  append()
  {
  alert("Appended to the File");
  }

  search()
  {
  alert("Searching in File.....");
  }
}
