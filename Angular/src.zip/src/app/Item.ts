import { Category } from './Category';

export class Item{
    name:string;
    price:number;
    category:Category;
    discounted_price:number;
    item_image:any;
    constructor(name: string, price: number, category: Category, discounted_price: number, item_image: any)
    {
        this.name=name;
        this.price=price;
        this.category=category;
        this.discounted_price=discounted_price;
        this.item_image=item_image;
    }
}