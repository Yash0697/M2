export class Category{
    name:string;
    //sub_categories:Category[];

    constructor(name:string){
        this.name=name;
        //this.sub_categories=sub_cats; //sub_cats:Category[]
    }
}