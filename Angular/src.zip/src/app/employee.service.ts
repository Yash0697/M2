import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {EmployeeInfo} from './EmployeeInfo';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
private serviceUrl = "https://jsonplaceholder.typicode.com/users";
  constructor(private http : HttpClient) { }

getEmp():Observable<EmployeeInfo[]>{
 return this.http.get<EmployeeInfo[]>(this.serviceUrl);
}

}
