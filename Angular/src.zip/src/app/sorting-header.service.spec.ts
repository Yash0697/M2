import { TestBed } from '@angular/core/testing';

import { SortingHeaderService } from './sorting-header.service';

describe('SortingHeaderService', () => {
  let service: SortingHeaderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SortingHeaderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
